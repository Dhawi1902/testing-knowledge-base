# k6 Track

Load testing scripts for the Pizza Playground, built to run against a laptop-sized
target and scale up to the profiles from the Performance Testing module (smoke,
load, stress, endurance, spike). Docs and write-ups live at
[`docs/k6/index.md`](../docs/k6/index.md).

**Prerequisites:** k6 v2.2.0, Pizza Playground running (`docker compose up -d` from
the `pizza-playground` repo).

## Scripts

| Script | Command |
| --- | --- |
| `01-first-test.js` | `k6 run 01-first-test.js` |
| `02-auth.js` | `k6 run 02-auth.js` |
| `03-order-flow.js` | `k6 run 03-order-flow.js` |
| `04-thresholds.js` | `k6 run 04-thresholds.js` |
| `05-load-model.js` | `k6 run -e PROFILE=load -e SCALE=0.02 05-load-model.js` (dry run — see [Load Model](../docs/k6/08-load-model.md) for the full-length command, ~31.5 min unscaled) |

Run from `k6/sample/`.

## `-e` switches

| Name | Meaning | Default | Read by |
| --- | --- | --- | --- |
| `BASE_URL` | Target base URL | `http://127.0.0.1:8080` | `lib/config.js`, used by every script |
| `USERS` | Peak VUs (`PEAK` in `lib/config.js`). For arrival-rate executors it sizes the VU pool, not the rate: `preAllocatedVUs = USERS`, `maxVUs = USERS × 5` | `10` | `05-load-model.js`, via `lib/config.js` |
| `SCALE` | Shrinks every stage duration for a dry run | `1` | `05-load-model.js`, via `lib/config.js` |
| `PROFILE` | Stage profile: smoke, load, stress, endurance or spike | `smoke` | `05-load-model.js` |
| `EXECUTOR` | k6 executor to use for the load model, or `mixed` | `ramping-vus` | `05-load-model.js` |
| `RATE` | Target iteration rate, per second, for arrival-rate executors — the actual throughput number, separate from `USERS` | `5` | `05-load-model.js` |
| `THINK` | Think time between requests (seconds) | `1` | `05-load-model.js` |
| `AUTOPAY` | Whether the order flow auto-completes payment | `true` | `03-order-flow.js`, `04-thresholds.js` |
| `MOCK_DELAY` | Simulated latency (ms) injected by the mock payment gateway | none | `03-order-flow.js` |
| `CUSTOMER_VUS` | Per-VU login count in `02-auth.js`'s `per_vu_login` scenario | `5` | `02-auth.js` |
