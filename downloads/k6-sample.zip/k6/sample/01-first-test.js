import http from 'k6/http';
import { check, sleep } from 'k6';
import { API } from './lib/config.js';

export const options = {
  vus: 1,
  duration: '10s',
  thresholds: {
    checks: ['rate==1'],            // every check must pass
    http_req_duration: ['p(95)<500'],
  },
};

export default function () {
  const res = http.get(`${API}/menu`);
  check(res, {
    'status is 200': (r) => r.status === 200,
    'menu has pizzas': (r) => r.json('pizzas').length > 0,
  });
  sleep(1);
}
