import http from 'k6/http';
import { sleep } from 'k6';
import { textSummary } from 'https://jslib.k6.io/k6-summary/0.1.0/index.js';
import { API, PEAK, t, stages } from './lib/config.js';
import { login, authHeaders, resetPlayground } from './lib/auth.js';
import { customerFor } from './lib/data.js';
import { getMenu, createOrder } from './lib/flow.js';

const PROFILE = __ENV.PROFILE || 'smoke';
const EXECUTOR = __ENV.EXECUTOR || 'ramping-vus';
const RATE = Number(__ENV.RATE || 5);     // orders per second, for arrival-rate executors
const THINK = Number(__ENV.THINK ?? 1);   // seconds; set 0 with arrival-rate executors

const scenarios = {
  // Fixed amount of work, split across VUs (fast VUs do more).
  'shared-iterations': { executor: 'shared-iterations', vus: PEAK, iterations: PEAK * 10, maxDuration: t(600) },
  // Every VU does the same number of iterations.
  'per-vu-iterations': { executor: 'per-vu-iterations', vus: PEAK, iterations: 10, maxDuration: t(600) },
  // N users for a fixed time. Closest to a plain JMeter Thread Group.
  'constant-vus': { executor: 'constant-vus', vus: PEAK, duration: t(300) },
  // Users follow the PROFILE shape. This is how smoke/load/stress/endurance/spike run.
  'ramping-vus': { executor: 'ramping-vus', startVUs: 0, stages: stages(PROFILE, PEAK), gracefulRampDown: '30s' },
  // A fixed request rate, whatever the response time. For "200 TPS" style NFRs.
  'constant-arrival-rate': {
    executor: 'constant-arrival-rate', rate: RATE, timeUnit: '1s', duration: t(300),
    preAllocatedVUs: PEAK, maxVUs: PEAK * 5,
  },
  // The PROFILE shape, but in orders per second instead of users.
  'ramping-arrival-rate': {
    executor: 'ramping-arrival-rate', startRate: 0, timeUnit: '1s', stages: stages(PROFILE, RATE),
    preAllocatedVUs: PEAK, maxVUs: PEAK * 5,
  },
};

// Two populations in one run: browsers who never order, and buyers at a fixed rate.
const mixed = {
  browsers: { executor: 'ramping-vus', stages: stages(PROFILE, PEAK), exec: 'browse' },
  buyers: {
    executor: 'constant-arrival-rate', rate: RATE, timeUnit: '1s', duration: t(300),
    preAllocatedVUs: PEAK, maxVUs: PEAK * 5, exec: 'buy',
  },
};

function pickScenarios() {
  if (EXECUTOR === 'mixed') return mixed;
  if (!scenarios[EXECUTOR]) {
    throw new Error(`Unknown EXECUTOR "${EXECUTOR}". Use ${Object.keys(scenarios).join(', ')} or mixed.`);
  }
  return { [EXECUTOR]: { ...scenarios[EXECUTOR], exec: 'buy' } };
}

export const options = {
  scenarios: pickScenarios(),
  thresholds: {
    http_req_duration: ['avg<3000'],  // NFR: average response time <= 3s
    http_req_failed: ['rate<0.005'],  // NFR: error rate <= 0.5%
  },
};

export function setup() {
  resetPlayground();
}

export function browse() {
  getMenu();
  sleep(THINK);
}

let token;
export function buy() {
  const me = customerFor(__VU);
  if (!token) token = login(me.email, me.password);
  createOrder(token, me, getMenu(), { autoPay: true });
  sleep(THINK);
}

// After the run: the highest order number proves how many orders really landed.
// GET /admin/orders with no status returns only active orders (NEW/PREPARING/READY),
// unpaginated. autoPay orders from this script stay NEW, so the count is complete.
export function teardown() {
  const owner = login('owner@playground.local', 'Password123!');
  const res = http.get(`${API}/admin/orders`, { headers: authHeaders(owner) });
  const numbers = res.json().map((o) => o.orderNumber);
  if (numbers.length === 0) {
    console.log('no active orders');
    return;
  }
  console.log(`active orders: ${numbers.length}, highest order number: ${Math.max(...numbers)}`);
}

// Replaces the default end-of-test output: keep it on screen and save JSON for the report.
export function handleSummary(data) {
  const stamp = new Date().toISOString().slice(0, 16).replace(/[-:T]/g, '');
  return {
    stdout: textSummary(data, { indent: ' ', enableColors: true }),
    [`results/summary-${PROFILE}-${stamp}.json`]: JSON.stringify(data, null, 2),
  };
}
