import http from 'k6/http';
import { check, sleep } from 'k6';
import { API } from './lib/config.js';
import { login, authHeaders, resetPlayground } from './lib/auth.js';
import { customerFor } from './lib/data.js';

export const options = {
  scenarios: {
    // Pattern 1: one login in setup(), every VU reuses the token.
    shared_token: { executor: 'per-vu-iterations', vus: 2, iterations: 3, exec: 'adminBoard' },
    // Pattern 2: each VU logs in as its own customer, once.
    // CUSTOMER_VUS above 20 shows the CSV wrap-around.
    per_vu_login: { executor: 'per-vu-iterations', vus: Number(__ENV.CUSTOMER_VUS || 5), iterations: 3, exec: 'myOrders' },
  },
  thresholds: { checks: ['rate==1'] },
};

export function setup() {
  return { ownerToken: resetPlayground() }; // whatever setup() returns is passed to every VU
}

export function adminBoard(data) {
  const res = http.get(`${API}/admin/orders`, { headers: authHeaders(data.ownerToken) });
  check(res, { 'admin board 200': (r) => r.status === 200 });
  sleep(1);
}

let token; // module scope: one per VU, survives between iterations
export function myOrders() {
  const me = customerFor(__VU);
  if (!token) token = login(me.email, me.password);
  const res = http.get(`${API}/orders/mine`, { headers: authHeaders(token) });
  check(res, { 'my orders 200': (r) => r.status === 200 });
  sleep(1);
}
