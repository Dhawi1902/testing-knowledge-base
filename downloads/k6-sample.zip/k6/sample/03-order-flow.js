import { check, sleep } from 'k6';
import { login, resetPlayground } from './lib/auth.js';
import { customerFor } from './lib/data.js';
import { getMenu, createOrder, payOnGateway, waitUntilPaid } from './lib/flow.js';

const AUTOPAY = __ENV.AUTOPAY !== 'false';
const MOCK_DELAY = __ENV.MOCK_DELAY;

export const options = {
  vus: 3,
  iterations: 9,
  thresholds: { checks: ['rate==1'] },
};

export function setup() {
  resetPlayground();
}

let token;
export default function () {
  const me = customerFor(__VU);
  if (!token) token = login(me.email, me.password);

  const menu = getMenu();
  const order = createOrder(token, me, menu, { autoPay: AUTOPAY, mockDelay: MOCK_DELAY });
  if (!order) return;

  if (!AUTOPAY) {
    payOnGateway(order.payUrl); // payUrl was extracted from the create-order response
    check(order, { 'order paid via gateway': (o) => waitUntilPaid(o.orderId) });
  }
  sleep(1);
}
