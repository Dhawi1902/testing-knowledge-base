import { check, group, sleep } from 'k6';
import { Trend, Counter } from 'k6/metrics';
import { login, resetPlayground } from './lib/auth.js';
import { customerFor } from './lib/data.js';
import { getMenu, createOrder, payOnGateway, waitUntilPaid } from './lib/flow.js';

const orderToPaid = new Trend('order_to_paid', true); // true = time values
const ordersPlaced = new Counter('orders_placed');
const AUTOPAY = __ENV.AUTOPAY !== 'false';

export const options = {
  vus: 3,
  duration: '30s',
  thresholds: {
    checks: ['rate==1'],
    http_req_failed: ['rate<0.005'],                           // NFR: error rate <= 0.5%
    'http_req_duration{name:GET /menu}': ['p(95)<300'],        // per endpoint, via the name tag
    'http_req_duration{name:POST /orders}': ['p(95)<1000'],
    'group_duration{group:::order}': ['avg<3000'],             // NFR: whole step <= 3s
    order_to_paid: ['p(95)<5000'],
    // Stop early instead of burning an hour on a run that already failed.
    http_req_duration: [{ threshold: 'p(99)<3000', abortOnFail: true, delayAbortEval: '10s' }],
  },
};

export function setup() {
  resetPlayground();
}

let token;
export default function () {
  const me = customerFor(__VU);
  if (!token) token = login(me.email, me.password);

  let menu;
  group('browse', () => {
    menu = getMenu();
  });
  sleep(1); // think time: reading the menu

  group('order', () => {
    const start = Date.now();
    const order = createOrder(token, me, menu, { autoPay: AUTOPAY });
    if (!order) return;
    if (!AUTOPAY) {
      payOnGateway(order.payUrl);
      const paid = check(order, { 'order paid via gateway': (o) => waitUntilPaid(o.orderId) });
      if (!paid) return;
    }
    // With autoPay the playground marks the order paid inside the create call,
    // so this is still create-to-paid even though there's no separate wait here.
    orderToPaid.add(Date.now() - start);
    ordersPlaced.add(1);
  });
  sleep(1);
}
