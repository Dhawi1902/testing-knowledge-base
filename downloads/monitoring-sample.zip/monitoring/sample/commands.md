# Commands

The four monitoring tools, started by hand one at a time, next to the Pizza Playground.

## Before you start

Start the playground first, in its own folder:

```bash
cd /path/to/pizza-playground
docker compose up -d --wait
```

Then run everything below from the folder that contains `monitoring/` (the root of this repo).

## Find the playground network

The monitoring containers join the playground's network so they can reach `db`, `api` and the others by name.

The network name comes from the running playground `api` container, so it works whatever folder the playground was cloned into.

```bash
NET=$(docker ps --filter label=com.docker.compose.service=api --format '{{.Networks}}' | head -1)
PROJECT=$(docker ps --filter label=com.docker.compose.service=api --format '{{.Label "com.docker.compose.project"}}' | head -1)
[ -n "$NET" ] && [ -n "$PROJECT" ] || echo "Playground is not running: start it first (docker compose up -d --wait in its folder)"
echo "$NET" "$PROJECT"
```

`PROJECT` is the playground's compose project name. Alloy uses it to ignore containers from any other compose app on the machine.

Expected: `pizza-playground_default pizza-playground` (the guard message appears instead if the playground is down).

## Start Prometheus

```bash
docker run -d --name prometheus --network "$NET" -p 9090:9090 \
  -v "$PWD/monitoring/sample/prometheus/prometheus.yml:/etc/prometheus/prometheus.yml:ro" \
  prom/prometheus:v3.15.0 \
  --config.file=/etc/prometheus/prometheus.yml --web.enable-remote-write-receiver
```

Check:

```bash
curl -s localhost:9090/-/ready
```

Expected: `Prometheus Server is Ready.`

## Start Loki

```bash
docker run -d --name loki --network "$NET" -p 3100:3100 grafana/loki:3.7.8
```

Check (it can say `Ingester not ready` for about 15 seconds, then retry):

```bash
curl -s localhost:3100/ready
```

Expected: `ready`

## Start Alloy

```bash
# Mounts, smallest set that worked on OrbStack (macOS):
#   docker.sock           lets Alloy list containers and read their logs
#   /sys                  cgroup files where CPU and memory are counted
#   /var/lib/docker       cAdvisor reads container disk usage here
#   /run/docker/containerd  containerd socket, needed by cAdvisor to name containers
# Docker Desktop and plain Linux were not tested: the containerd socket is usually
# /run/containerd/containerd.sock there, so mount that instead and remove the
# containerd_host line in config.alloy. No --privileged and no "-v /:/rootfs" were needed.
docker run -d --name alloy --network "$NET" -p 12345:12345 \
  -e PLAYGROUND_PROJECT="$PROJECT" \
  -v "$PWD/monitoring/sample/alloy/config.alloy:/etc/alloy/config.alloy:ro" \
  -v /var/run/docker.sock:/var/run/docker.sock:ro \
  -v /sys:/sys:ro \
  -v /var/lib/docker/:/var/lib/docker:ro \
  -v /run/docker/containerd:/run/docker/containerd:ro \
  grafana/alloy:v1.20.1 \
  run --server.http.listen-addr=0.0.0.0:12345 /etc/alloy/config.alloy
```

Check:

```bash
curl -s localhost:12345/-/ready
```

Expected: `Alloy is ready.` If not, `docker logs alloy` shows which block of `config.alloy` failed.

Check that per-container CPU series arrive (wait about 30 seconds after the start):

```bash
curl -s localhost:9090/api/v1/query --data-urlencode 'query=rate(container_cpu_usage_seconds_total{service!=""}[1m])' | python3 -c 'import sys,json;print(sorted(x["metric"]["service"] for x in json.load(sys.stdin)["data"]["result"]))'
```

Expected: `['api', 'db', 'mock-gateway', 'web']`. If the list is empty, `docker logs alloy` and look at the cAdvisor lines (see the containerd note in the mount comments above).

Check that Loki receives the logs:

```bash
curl -s localhost:3100/loki/api/v1/label/service/values
```

Expected: `{"status":"success","data":["api","db","mock-gateway","web"]}`

After you edit `config.alloy`, recreate the container (`docker rm -f alloy`, then the `docker run` again). A plain `docker restart alloy` can lose the mounted file when an editor replaces it instead of changing it in place.

On the first start Alloy also sends old log lines it finds. Loki refuses the ones older than its limit, so `docker logs alloy` shows a few `entry too far behind` errors. They are harmless.

## Start Grafana

```bash
docker run -d --name grafana --network "$NET" -p 3001:3000 grafana/grafana:13.2.3
```

Check:

```bash
curl -s -o /dev/null -w '%{http_code}\n' localhost:3001/login
```

Expected: `200`. Open http://localhost:3001 and log in with `admin` / `admin`.

## Run a load test with results in Prometheus

Run from the repo root, or from the folder where you unzipped both samples. Prometheus must be started with `--web.enable-remote-write-receiver` (see "Start Prometheus"). Without the two `K6_PROMETHEUS_RW_` variables, k6 sends nothing.

```bash
cd k6/sample
K6_PROMETHEUS_RW_SERVER_URL=http://127.0.0.1:9090/api/v1/write \
K6_PROMETHEUS_RW_TREND_STATS="p(95),avg,max" \
k6 run -o experimental-prometheus-rw -e PROFILE=load -e SCALE=0.1 -e USERS=30 05-load-model.js
```

Check that k6 data arrived:

```bash
curl -s localhost:9090/api/v1/query --data-urlencode 'query=k6_http_reqs_total' | python3 -c 'import sys,json;print(len(json.load(sys.stdin)["data"]["result"]),"series")'
```

## Trigger the error alert

Run from the playground folder. Each request hangs while the db is down, so the requests go out in parallel and `curl -m 5` gives up on them after 5 seconds.

```bash
cd /path/to/pizza-playground
docker compose stop db
for i in $(seq 12); do curl -s -m 5 -o /dev/null http://127.0.0.1:8080/api/v1/menu & done; wait
sleep 40
docker compose start db
```

The api only logs the errors about 30 seconds after each request, so keep the db down for the full 45 seconds (5 s of `curl -m 5` plus `sleep 40`). If you start it sooner, the waiting requests succeed and nothing is logged. Expected: about 36 `ERROR` lines in Loki and the `api ERROR lines` rule goes Pending, then Firing.

## Start again after a restart

```bash
docker start prometheus loki alloy grafana
```

Prometheus and Loki are started without volumes, so what they stored lives inside the container. `docker stop` and `docker start` keep it; `docker rm -f` (or recreating a container) loses all history.

What happens when the playground is brought down and up again (`docker compose down`, then `up`):

- If the monitoring containers are still **running**, `down` cannot remove the playground network (it prints `Resource is still in use`), `up` reuses it, and monitoring keeps working. Nothing to do.
- If the monitoring containers were **stopped** first, `down` removes the network and `up` creates a new one, so `docker start` fails with `network ... not found`. Recreate the four containers from the sections above (`docker rm -f` them first); the history is lost.

## Tear down

```bash
docker rm -f prometheus loki alloy grafana
```
