# Monitoring sample

A hands-on monitoring stack for the Pizza Playground: Alloy collects container metrics, Postgres metrics and container logs; Prometheus stores the metrics; Loki stores the logs; Grafana shows both. Each tool is one `docker run`, started by hand next to the already-running playground. No compose file, and nothing in the playground is changed.

Run it: follow [`sample/commands.md`](sample/commands.md) from top to bottom.

The explanation lives in the docs: `docs/monitoring/`.
